---
name: design-md
description: Design system collection from top companies including Apple, Airbnb, Stripe, Notion, and 50+ other brands. Provides comprehensive design guidelines, color systems, typography, and component patterns.
---

# Design-MD Skill

Comprehensive design system collection featuring 59+ company design systems including Apple, Airbnb, Stripe, Notion, Linear, Figma, Vercel, and more. Each design system provides detailed guidelines for colors, typography, components, spacing, and interaction patterns.

## How to Use This Skill

When user requests design work with a specific brand style or wants to apply professional design systems, follow this workflow:

### Step 1: Identify Design System

Ask user which company's design system they want to use, or recommend based on their project type:

**Common Design Systems:**
- **Apple**: Clean, minimal, human interface guidelines
- **Stripe**: Modern fintech, developer-friendly
- **Notion**: Simple, functional, productivity-focused
- **Linear**: Fast, keyboard-first, project management
- **Airbnb**: Warm, welcoming, travel/hospitality
- **Figma**: Collaborative, design tool interface
- **Vercel**: Developer experience, deployment platform
- **Spotify**: Music, entertainment, dark mode
- **Tesla**: Futuristic, automotive, innovation
- **Coinbase**: Crypto, financial trust, security

### Step 2: Access Design System

Each design system is located in `C:\Users\Administrator\.lingma\skills\design-md\<company-name>\`

To use a specific design system:

```bash
# View design system documentation
cat C:\Users\Administrator\.lingma\skills\design-md\<company>\README.md
```

**Note**: Most design systems have moved their detailed documentation to https://getdesign.md/

Access online resources at:
- `https://getdesign.md/<company>/design-md`

For example:
- Apple: `https://getdesign.md/apple/design-md`
- Stripe: `https://getdesign.md/stripe/design-md`
- Notion: `https://getdesign.md/notion/design-md`

### Step 3: Apply Design System

When implementing a design system, consider these key aspects:

#### 1. **Color Palette**
- Primary, secondary, and accent colors
- Light/dark mode variations
- Semantic colors (success, warning, error)

#### 2. **Typography**
- Font families (usually custom or Google Fonts)
- Type scale (h1-h6, body, caption)
- Line heights and letter spacing

#### 3. **Spacing & Layout**
- Grid system (8pt, 4pt grids common)
- Spacing scale (4, 8, 12, 16, 24, 32, etc.)
- Breakpoints for responsive design

#### 4. **Components**
- Buttons, cards, inputs, modals
- Navigation patterns
- Data display components

#### 5. **Interaction Patterns**
- Hover states
- Transitions and animations
- Loading states
- Error handling

### Step 4: Implementation Guidelines

**For HTML/Tailwind projects:**
```html
<!-- Example: Applying Apple-inspired design -->
<div class="bg-white dark:bg-gray-900">
  <h1 class="text-4xl font-semibold tracking-tight text-gray-900 dark:text-white">
    Clean Typography
  </h1>
  <button class="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
    Action Button
  </button>
</div>
```

**Key Principles:**
1. **Consistency**: Use the same spacing, colors, and typography throughout
2. **Accessibility**: Ensure proper contrast ratios (4.5:1 minimum)
3. **Responsiveness**: Design for mobile-first, then enhance for larger screens
4. **Performance**: Optimize assets and minimize layout shifts

## Available Design Systems

### Technology Companies
- **Apple** - Human Interface Guidelines
- **Google/Material** - Material Design 3
- **Microsoft/Fluent** - Fluent Design System
- **IBM** - Carbon Design System
- **Salesforce** - Lightning Design System

### SaaS Products
- **Linear** - Fast, keyboard-first project management
- **Notion** - Simple, flexible workspace
- **Figma** - Collaborative design platform
- **Vercel** - Developer experience platform
- **Stripe** - Payment infrastructure
- **Supabase** - Open-source Firebase alternative
- **Resend** - Email API for developers
- **Raycast** - Productivity launcher
- **Superhuman** - Email client
- **Cal.com** - Scheduling infrastructure

### Fintech & Crypto
- **Coinbase** - Cryptocurrency exchange
- **Revolut** - Digital banking
- **Wise** - International money transfers
- **Kraken** - Crypto exchange
- **Stripe** - Payment processing

### AI & Developer Tools
- **OpenAI** - AI research and deployment
- **Anthropic/Claude** - AI assistant
- **Cursor** - AI code editor
- **Replit** - Online IDE
- **Ollama** - Local LLM runner
- **Hugging Face** - ML community
- **Cohere** - Enterprise AI
- **Mistral.ai** - Open-weight models
- **Together.ai** - AI inference platform
- **x.ai** - AI research
- **Minimax** - AI technology

### Design & Creative
- **Framer** - Web design tool
- **Webflow** - Visual web development
- **Lovable** - AI app builder
- **RunwayML** - AI video generation
- **ElevenLabs** - AI voice synthesis
- **Sanity** - Content platform
- **Miro** - Visual collaboration
- **Pinterest** - Visual discovery

### Automotive & Luxury
- **Tesla** - Electric vehicles
- **BMW** - Luxury automobiles
- **Mercedes** - Premium cars
- **Ferrari** - Sports cars
- **Lamborghini** - Supercars
- **Renault** - Automotive

### Other Notable Systems
- **Airbnb** - Hospitality and travel
- **Uber** - Ride-sharing platform
- **Spotify** - Music streaming
- **Netflix** - Entertainment streaming
- **Shopify** - E-commerce platform
- **Intercom** - Customer messaging
- **PostHog** - Product analytics
- **Sentry** - Error tracking
- **MongoDB** - Database platform
- **ClickHouse** - Analytics database
- **HashiCorp** - Cloud infrastructure
- **Zapier** - Workflow automation
- **Semrush** - SEO toolkit
- **Clay** - Data enrichment
- **Composio** - AI agent tools
- **Voltagent** - AI agents
- **Warp** - Terminal reimagined
- **Mintlify** - Documentation platform
- **Replicate** - ML model hosting
- **Expo** - React Native framework

## Quick Start Examples

### Example 1: Apply Stripe-style Design
```bash
# Access Stripe design system
# URL: https://getdesign.md/stripe/design-md

# Key characteristics:
# - Clean, modern aesthetic
# - Purple/blue gradient accents
# - Generous whitespace
# - Rounded corners (8-12px)
# - Subtle shadows and borders
```

### Example 2: Apply Apple-style Design
```bash
# Access Apple design system
# URL: https://getdesign.md/apple/design-md

# Key characteristics:
# - Minimal, clean interface
# - San Francisco font family
# - Subtle gradients
# - Frosted glass effects
# - Precise spacing (8pt grid)
```

### Example 3: Apply Notion-style Design
```bash
# Access Notion design system
# URL: https://getdesign.md/notion/design-md

# Key characteristics:
# - Simple, functional design
# - Neutral color palette
# - Block-based layout
# - Emoji icons
# - Clean typography
```

## Best Practices

### 1. Choose the Right Design System
Match the design system to your product type:
- **SaaS Dashboard**: Linear, Notion, Vercel
- **E-commerce**: Shopify, Airbnb
- **Fintech**: Stripe, Coinbase, Revolut
- **Developer Tool**: Vercel, Stripe, Supabase
- **Creative Tool**: Figma, Framer, Webflow

### 2. Adapt, Don't Copy
- Use design systems as inspiration
- Adapt to your brand identity
- Maintain consistency within your product
- Consider your target audience

### 3. Focus on Key Elements
Prioritize these aspects when applying a design system:
1. **Color palette** - Most visible brand element
2. **Typography** - Sets the tone and readability
3. **Spacing** - Creates visual rhythm
4. **Components** - Ensures consistency
5. **Interactions** - Delights users

### 4. Test and Iterate
- Test with real users
- Gather feedback on usability
- Iterate based on data
- Maintain design consistency

## Resources

- **Online Documentation**: https://getdesign.md/<company>/design-md
- **Local Files**: `C:\Users\Administrator\.lingma\skills\design-md\<company>\README.md`
- **Design Inspiration**: Dribbble, Behance, Awwwards
- **Component Libraries**: Radix UI, Headless UI, Chakra UI

## Tips for Better Results

1. **Be specific about style** - "I want a Stripe-like checkout page" vs "make it look nice"
2. **Reference multiple systems** - Combine elements from different systems
3. **Consider context** - Different pages may need different approaches
4. **Document decisions** - Keep track of design choices for consistency
5. **Use design tokens** - Define colors, spacing, typography as variables

## Common Design Patterns

### Hero Sections
- Large, bold headlines
- Clear value proposition
- Strong call-to-action
- Supporting imagery or illustration

### Card Layouts
- Consistent padding (16-24px)
- Subtle borders or shadows
- Clear hierarchy
- Hover states for interactivity

### Forms
- Clear labels above inputs
- Helpful error messages
- Progressive disclosure
- Validation feedback

### Navigation
- Clear current state
- Logical grouping
- Accessible keyboard navigation
- Mobile-responsive patterns

---

**Ready to apply a design system?** Tell me which company's design style you'd like to use, or describe your project and I'll recommend the best fit!
