const fs = require('node:fs');
const path = require('node:path');

const { DATA_DIR, search } = require('./core.js');

const REASONING_FILE = 'ui-reasoning.csv';
const SEARCH_CONFIG = {
  product: { max_results: 1 },
  style: { max_results: 3 },
  color: { max_results: 2 },
  landing: { max_results: 2 },
  typography: { max_results: 2 },
};
const BOX_WIDTH = 90;

function slugify(value) {
  return String(value || 'default').trim().toLowerCase().replace(/\s+/g, '-');
}

function timestamp() {
  const date = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function wrapText(text, prefix, width) {
  if (!text) return [];
  const words = String(text).split(/\s+/);
  const lines = [];
  let current = prefix;

  for (const word of words) {
    const candidate = current === prefix ? `${prefix}${word}` : `${current} ${word}`;
    if (candidate.length <= width - 2) {
      current = candidate;
    } else {
      if (current !== prefix) lines.push(current);
      current = `${prefix}${word}`;
    }
  }

  if (current !== prefix) lines.push(current);
  return lines;
}

class DesignSystemGenerator {
  constructor() {
    this.reasoningData = this.loadReasoning();
  }

  loadReasoning() {
    const filepath = path.join(DATA_DIR, REASONING_FILE);
    if (!fs.existsSync(filepath)) return [];
    const { loadCsv } = require('./core.js');
    return loadCsv(filepath);
  }

  multiDomainSearch(query, stylePriority = []) {
    const results = {};
    for (const [domain, config] of Object.entries(SEARCH_CONFIG)) {
      if (domain === 'style' && stylePriority.length > 0) {
        const priorityQuery = stylePriority.slice(0, 2).join(' ');
        results[domain] = search(`${query} ${priorityQuery}`.trim(), domain, config.max_results);
      } else {
        results[domain] = search(query, domain, config.max_results);
      }
    }
    return results;
  }

  findReasoningRule(category) {
    const categoryLower = String(category || '').toLowerCase();

    for (const rule of this.reasoningData) {
      if ((rule.UI_Category || '').toLowerCase() === categoryLower) return rule;
    }

    for (const rule of this.reasoningData) {
      const uiCat = (rule.UI_Category || '').toLowerCase();
      if (uiCat.includes(categoryLower) || categoryLower.includes(uiCat)) return rule;
    }

    for (const rule of this.reasoningData) {
      const uiCat = (rule.UI_Category || '').toLowerCase();
      const keywords = uiCat.replaceAll('/', ' ').replaceAll('-', ' ').split(/\s+/).filter(Boolean);
      if (keywords.some((kw) => categoryLower.includes(kw))) return rule;
    }

    return {};
  }

  applyReasoning(category) {
    const rule = this.findReasoningRule(category);
    if (!rule || Object.keys(rule).length === 0) {
      return {
        pattern: 'Hero + Features + CTA',
        style_priority: ['Minimalism', 'Flat Design'],
        color_mood: 'Professional',
        typography_mood: 'Clean',
        key_effects: 'Subtle hover transitions',
        anti_patterns: '',
        decision_rules: {},
        severity: 'MEDIUM',
      };
    }

    let decisionRules = {};
    try {
      decisionRules = JSON.parse(rule.Decision_Rules || '{}');
    } catch {
      decisionRules = {};
    }

    return {
      pattern: rule.Recommended_Pattern || '',
      style_priority: String(rule.Style_Priority || '').split('+').map((s) => s.trim()).filter(Boolean),
      color_mood: rule.Color_Mood || '',
      typography_mood: rule.Typography_Mood || '',
      key_effects: rule.Key_Effects || '',
      anti_patterns: rule.Anti_Patterns || '',
      decision_rules: decisionRules,
      severity: rule.Severity || 'MEDIUM',
    };
  }

  selectBestMatch(results, priorityKeywords = []) {
    if (!results || results.length === 0) return {};
    if (!priorityKeywords || priorityKeywords.length === 0) return results[0];

    for (const priority of priorityKeywords) {
      const priorityLower = priority.toLowerCase().trim();
      for (const result of results) {
        const styleName = String(result['Style Category'] || '').toLowerCase();
        if (styleName.includes(priorityLower) || priorityLower.includes(styleName)) return result;
      }
    }

    const scored = results.map((result) => {
      const resultStr = JSON.stringify(result).toLowerCase();
      let score = 0;
      for (const kw of priorityKeywords) {
        const kwLower = kw.toLowerCase().trim();
        if (String(result['Style Category'] || '').toLowerCase().includes(kwLower)) score += 10;
        else if (String(result.Keywords || '').toLowerCase().includes(kwLower)) score += 3;
        else if (resultStr.includes(kwLower)) score += 1;
      }
      return { score, result };
    }).sort((a, b) => b.score - a.score);

    return scored[0] && scored[0].score > 0 ? scored[0].result : results[0];
  }

  generate(query, projectName = null) {
    const productResult = search(query, 'product', 1);
    const productResults = productResult.results || [];
    const category = productResults.length > 0 ? (productResults[0]['Product Type'] || 'General') : 'General';

    const reasoning = this.applyReasoning(category);
    const stylePriority = reasoning.style_priority || [];
    const searchResults = this.multiDomainSearch(query, stylePriority);
    searchResults.product = productResult;

    const styleResults = searchResults.style?.results || [];
    const colorResults = searchResults.color?.results || [];
    const typographyResults = searchResults.typography?.results || [];
    const landingResults = searchResults.landing?.results || [];

    const bestStyle = this.selectBestMatch(styleResults, stylePriority);
    const bestColor = colorResults[0] || {};
    const bestTypography = typographyResults[0] || {};
    const bestLanding = landingResults[0] || {};
    const styleEffects = bestStyle['Effects & Animation'] || '';
    const reasoningEffects = reasoning.key_effects || '';
    const combinedEffects = styleEffects || reasoningEffects;

    return {
      project_name: projectName || String(query).toUpperCase(),
      category,
      pattern: {
        name: bestLanding['Pattern Name'] || reasoning.pattern || 'Hero + Features + CTA',
        sections: bestLanding['Section Order'] || 'Hero > Features > CTA',
        cta_placement: bestLanding['Primary CTA Placement'] || 'Above fold',
        color_strategy: bestLanding['Color Strategy'] || '',
        conversion: bestLanding['Conversion Optimization'] || '',
      },
      style: {
        name: bestStyle['Style Category'] || 'Minimalism',
        type: bestStyle.Type || 'General',
        effects: styleEffects,
        keywords: bestStyle.Keywords || '',
        best_for: bestStyle['Best For'] || '',
        performance: bestStyle.Performance || '',
        accessibility: bestStyle.Accessibility || '',
      },
      colors: {
        primary: bestColor['Primary (Hex)'] || '#2563EB',
        secondary: bestColor['Secondary (Hex)'] || '#3B82F6',
        cta: bestColor['CTA (Hex)'] || '#F97316',
        background: bestColor['Background (Hex)'] || '#F8FAFC',
        text: bestColor['Text (Hex)'] || '#1E293B',
        notes: bestColor.Notes || '',
      },
      typography: {
        heading: bestTypography['Heading Font'] || 'Inter',
        body: bestTypography['Body Font'] || 'Inter',
        mood: bestTypography['Mood/Style Keywords'] || reasoning.typography_mood || '',
        best_for: bestTypography['Best For'] || '',
        google_fonts_url: bestTypography['Google Fonts URL'] || '',
        css_import: bestTypography['CSS Import'] || '',
      },
      key_effects: combinedEffects,
      anti_patterns: reasoning.anti_patterns || '',
      decision_rules: reasoning.decision_rules || {},
      severity: reasoning.severity || 'MEDIUM',
    };
  }
}

function formatAsciiBox(designSystem) {
  const project = designSystem.project_name || 'PROJECT';
  const pattern = designSystem.pattern || {};
  const style = designSystem.style || {};
  const colors = designSystem.colors || {};
  const typography = designSystem.typography || {};
  const effects = designSystem.key_effects || '';
  const antiPatterns = designSystem.anti_patterns || '';
  const sections = String(pattern.sections || '').split('>').map((s) => s.trim()).filter(Boolean);
  const lines = [];
  const w = BOX_WIDTH - 1;

  lines.push(`+${'-'.repeat(w)}+`);
  lines.push(`|  TARGET: ${project} - RECOMMENDED DESIGN SYSTEM`.padEnd(BOX_WIDTH) + '|');
  lines.push(`+${'-'.repeat(w)}+`);
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  lines.push(`|  PATTERN: ${pattern.name || ''}`.padEnd(BOX_WIDTH) + '|');
  if (pattern.conversion) lines.push(`|     Conversion: ${pattern.conversion}`.padEnd(BOX_WIDTH) + '|');
  if (pattern.cta_placement) lines.push(`|     CTA: ${pattern.cta_placement}`.padEnd(BOX_WIDTH) + '|');
  lines.push('|     Sections:'.padEnd(BOX_WIDTH) + '|');
  sections.forEach((section, index) => lines.push(`|       ${index + 1}. ${section}`.padEnd(BOX_WIDTH) + '|'));
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  lines.push(`|  STYLE: ${style.name || ''}`.padEnd(BOX_WIDTH) + '|');
  wrapText(`Keywords: ${style.keywords || ''}`, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
  wrapText(`Best For: ${style.best_for || ''}`, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
  if (style.performance || style.accessibility) {
    lines.push(`|     Performance: ${style.performance || ''} | Accessibility: ${style.accessibility || ''}`.padEnd(BOX_WIDTH) + '|');
  }
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  lines.push('|  COLORS:'.padEnd(BOX_WIDTH) + '|');
  lines.push(`|     Primary:    ${colors.primary || ''}`.padEnd(BOX_WIDTH) + '|');
  lines.push(`|     Secondary:  ${colors.secondary || ''}`.padEnd(BOX_WIDTH) + '|');
  lines.push(`|     CTA:        ${colors.cta || ''}`.padEnd(BOX_WIDTH) + '|');
  lines.push(`|     Background: ${colors.background || ''}`.padEnd(BOX_WIDTH) + '|');
  lines.push(`|     Text:       ${colors.text || ''}`.padEnd(BOX_WIDTH) + '|');
  wrapText(`Notes: ${colors.notes || ''}`, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  lines.push(`|  TYPOGRAPHY: ${typography.heading || ''} / ${typography.body || ''}`.padEnd(BOX_WIDTH) + '|');
  wrapText(`Mood: ${typography.mood || ''}`, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
  wrapText(`Best For: ${typography.best_for || ''}`, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
  if (typography.google_fonts_url) lines.push(`|     Google Fonts: ${typography.google_fonts_url}`.padEnd(BOX_WIDTH) + '|');
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  if (effects) {
    lines.push('|  KEY EFFECTS:'.padEnd(BOX_WIDTH) + '|');
    wrapText(effects, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
    lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  }
  if (antiPatterns) {
    lines.push('|  AVOID (Anti-patterns):'.padEnd(BOX_WIDTH) + '|');
    wrapText(antiPatterns, '|     ', BOX_WIDTH).forEach((line) => lines.push(line.padEnd(BOX_WIDTH) + '|'));
    lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  }
  lines.push('|  PRE-DELIVERY CHECKLIST:'.padEnd(BOX_WIDTH) + '|');
  [
    '[ ] No emojis as icons (use SVG: Heroicons/Lucide)',
    '[ ] cursor-pointer on all clickable elements',
    '[ ] Hover states with smooth transitions (150-300ms)',
    '[ ] Light mode: text contrast 4.5:1 minimum',
    '[ ] Focus states visible for keyboard nav',
    '[ ] prefers-reduced-motion respected',
    '[ ] Responsive: 375px, 768px, 1024px, 1440px',
  ].forEach((item) => lines.push(`|     ${item}`.padEnd(BOX_WIDTH) + '|'));
  lines.push('|' + ' '.repeat(BOX_WIDTH) + '|');
  lines.push(`+${'-'.repeat(w)}+`);
  return lines.join('\n');
}

function formatMarkdown(designSystem) {
  const project = designSystem.project_name || 'PROJECT';
  const pattern = designSystem.pattern || {};
  const style = designSystem.style || {};
  const colors = designSystem.colors || {};
  const typography = designSystem.typography || {};
  const effects = designSystem.key_effects || '';
  const antiPatterns = designSystem.anti_patterns || '';
  const lines = [];

  lines.push(`## Design System: ${project}`, '');
  lines.push('### Pattern');
  lines.push(`- **Name:** ${pattern.name || ''}`);
  if (pattern.conversion) lines.push(`- **Conversion Focus:** ${pattern.conversion}`);
  if (pattern.cta_placement) lines.push(`- **CTA Placement:** ${pattern.cta_placement}`);
  if (pattern.color_strategy) lines.push(`- **Color Strategy:** ${pattern.color_strategy}`);
  lines.push(`- **Sections:** ${pattern.sections || ''}`, '');
  lines.push('### Style');
  lines.push(`- **Name:** ${style.name || ''}`);
  if (style.keywords) lines.push(`- **Keywords:** ${style.keywords}`);
  if (style.best_for) lines.push(`- **Best For:** ${style.best_for}`);
  if (style.performance || style.accessibility) lines.push(`- **Performance:** ${style.performance || ''} | **Accessibility:** ${style.accessibility || ''}`);
  lines.push('');
  lines.push('### Colors', '| Role | Hex |', '|------|-----|', `| Primary | ${colors.primary || ''} |`, `| Secondary | ${colors.secondary || ''} |`, `| CTA | ${colors.cta || ''} |`, `| Background | ${colors.background || ''} |`, `| Text | ${colors.text || ''} |`);
  if (colors.notes) lines.push('', `*Notes: ${colors.notes}*`);
  lines.push('', '### Typography', `- **Heading:** ${typography.heading || ''}`, `- **Body:** ${typography.body || ''}`);
  if (typography.mood) lines.push(`- **Mood:** ${typography.mood}`);
  if (typography.best_for) lines.push(`- **Best For:** ${typography.best_for}`);
  if (typography.google_fonts_url) lines.push(`- **Google Fonts:** ${typography.google_fonts_url}`);
  if (typography.css_import) lines.push('- **CSS Import:**', '```css', typography.css_import, '```');
  lines.push('');
  if (effects) lines.push('### Key Effects', effects, '');
  if (antiPatterns) lines.push('### Avoid (Anti-patterns)', `- ${antiPatterns.replaceAll(' + ', '\n- ')}`, '');
  lines.push('### Pre-Delivery Checklist', '- [ ] No emojis as icons (use SVG: Heroicons/Lucide)', '- [ ] cursor-pointer on all clickable elements', '- [ ] Hover states with smooth transitions (150-300ms)', '- [ ] Light mode: text contrast 4.5:1 minimum', '- [ ] Focus states visible for keyboard nav', '- [ ] prefers-reduced-motion respected', '- [ ] Responsive: 375px, 768px, 1024px, 1440px', '');
  return lines.join('\n');
}

function formatMasterMd(designSystem) {
  const project = designSystem.project_name || 'PROJECT';
  const pattern = designSystem.pattern || {};
  const style = designSystem.style || {};
  const colors = designSystem.colors || {};
  const typography = designSystem.typography || {};
  const effects = designSystem.key_effects || '';
  const antiPatterns = designSystem.anti_patterns || '';

  const antiList = String(antiPatterns).split('+').map((item) => item.trim()).filter(Boolean);

  return [
    '# Design System Master File',
    '',
    '> **LOGIC:** When building a specific page, first check `design-system/pages/[page-name].md`.',
    '> If that file exists, its rules **override** this Master file.',
    '> If not, strictly follow the rules below.',
    '',
    '---',
    '',
    `**Project:** ${project}`,
    `**Generated:** ${timestamp()}`,
    `**Category:** ${designSystem.category || 'General'}`,
    '',
    '---',
    '',
    '## Global Rules',
    '',
    '### Color Palette',
    '',
    '| Role | Hex | CSS Variable |',
    '|------|-----|--------------|',
    `| Primary | \
\`${colors.primary || '#2563EB'}\` | \`--color-primary\` |`,
    `| Secondary | \`${colors.secondary || '#3B82F6'}\` | \`--color-secondary\` |`,
    `| CTA/Accent | \`${colors.cta || '#F97316'}\` | \`--color-cta\` |`,
    `| Background | \`${colors.background || '#F8FAFC'}\` | \`--color-background\` |`,
    `| Text | \`${colors.text || '#1E293B'}\` | \`--color-text\` |`,
    '',
    colors.notes ? `**Color Notes:** ${colors.notes}` : '',
    colors.notes ? '' : '',
    '### Typography',
    '',
    `- **Heading Font:** ${typography.heading || 'Inter'}`,
    `- **Body Font:** ${typography.body || 'Inter'}`,
    typography.mood ? `- **Mood:** ${typography.mood}` : '',
    typography.google_fonts_url ? `- **Google Fonts:** [${typography.heading || ''} + ${typography.body || ''}](${typography.google_fonts_url})` : '',
    '',
    typography.css_import ? '**CSS Import:**' : '',
    typography.css_import ? '```css' : '',
    typography.css_import || '',
    typography.css_import ? '```' : '',
    typography.css_import ? '' : '',
    '## Style Guidelines',
    '',
    `**Style:** ${style.name || 'Minimalism'}`,
    '',
    style.keywords ? `**Keywords:** ${style.keywords}` : '',
    style.keywords ? '' : '',
    style.best_for ? `**Best For:** ${style.best_for}` : '',
    style.best_for ? '' : '',
    effects ? `**Key Effects:** ${effects}` : '',
    effects ? '' : '',
    '### Page Pattern',
    '',
    `**Pattern Name:** ${pattern.name || ''}`,
    '',
    pattern.conversion ? `- **Conversion Strategy:** ${pattern.conversion}` : '',
    pattern.cta_placement ? `- **CTA Placement:** ${pattern.cta_placement}` : '',
    `- **Section Order:** ${pattern.sections || ''}`,
    '',
    '## Anti-Patterns (Do NOT Use)',
    '',
    ...antiList.map((anti) => `- ❌ ${anti}`),
    '- ❌ **Emojis as icons** — Use SVG icons (Heroicons, Lucide, Simple Icons)',
    '- ❌ **Missing cursor:pointer** — All clickable elements must have cursor:pointer',
    '- ❌ **Layout-shifting hovers** — Avoid scale transforms that shift layout',
    '- ❌ **Low contrast text** — Maintain 4.5:1 minimum contrast ratio',
    '- ❌ **Invisible focus states** — Focus states must be visible for a11y',
    '',
    '## Pre-Delivery Checklist',
    '',
    '- [ ] No emojis used as icons (use SVG instead)',
    '- [ ] All icons from consistent icon set (Heroicons/Lucide)',
    '- [ ] `cursor-pointer` on all clickable elements',
    '- [ ] Hover states with smooth transitions (150-300ms)',
    '- [ ] Light mode: text contrast 4.5:1 minimum',
    '- [ ] Focus states visible for keyboard navigation',
    '- [ ] `prefers-reduced-motion` respected',
    '- [ ] Responsive: 375px, 768px, 1024px, 1440px',
    '- [ ] No content hidden behind fixed navbars',
    '- [ ] No horizontal scroll on mobile',
    '',
  ].filter((line, index, arr) => !(line === '' && arr[index - 1] === '')).join('\n');
}

function detectPageType(context) {
  const contextLower = String(context || '').toLowerCase();
  const pagePatterns = [
    [['dashboard', 'admin', 'analytics', 'data', 'metrics', 'stats', 'monitor', 'overview'], 'Dashboard / Data View'],
    [['checkout', 'payment', 'cart', 'purchase', 'order', 'billing'], 'Checkout / Payment'],
    [['settings', 'profile', 'account', 'preferences', 'config'], 'Settings / Profile'],
    [['landing', 'marketing', 'homepage', 'hero', 'home', 'promo'], 'Landing / Marketing'],
    [['login', 'signin', 'signup', 'register', 'auth', 'password'], 'Authentication'],
    [['pricing', 'plans', 'subscription', 'tiers', 'packages'], 'Pricing / Plans'],
    [['blog', 'article', 'post', 'news', 'content', 'story'], 'Blog / Article'],
    [['product', 'item', 'detail', 'pdp', 'shop', 'store'], 'Product Detail'],
    [['search', 'results', 'browse', 'filter', 'catalog', 'list'], 'Search Results'],
    [['empty', '404', 'error', 'not found', 'zero'], 'Empty State'],
  ];
  for (const [keywords, pageType] of pagePatterns) {
    if (keywords.some((kw) => contextLower.includes(kw))) return pageType;
  }
  return 'General';
}

function generateIntelligentOverrides(pageName, pageQuery, designSystem) {
  const combinedContext = `${String(pageName || '').toLowerCase()} ${String(pageQuery || '').toLowerCase()}`.trim();
  const styleResults = search(combinedContext, 'style', 1).results || [];
  const uxResults = search(combinedContext, 'ux', 3).results || [];
  const landingResults = search(combinedContext, 'landing', 1).results || [];

  const layout = {};
  const spacing = {};
  const typography = {};
  const colors = {};
  const components = [];
  const uniqueComponents = [];
  const recommendations = [];

  if (styleResults[0]) {
    const style = styleResults[0];
    const keywords = String(style.Keywords || '').toLowerCase();
    const effects = style['Effects & Animation'] || '';
    if (['data', 'dense', 'dashboard', 'grid'].some((kw) => keywords.includes(kw))) {
      layout['Max Width'] = '1400px or full-width';
      layout.Grid = '12-column grid for data flexibility';
      spacing['Content Density'] = 'High — optimize for information display';
    } else if (['minimal', 'simple', 'clean', 'single'].some((kw) => keywords.includes(kw))) {
      layout['Max Width'] = '800px (narrow, focused)';
      layout.Layout = 'Single column, centered';
      spacing['Content Density'] = 'Low — focus on clarity';
    } else {
      layout['Max Width'] = '1200px (standard)';
      layout.Layout = 'Full-width sections, centered content';
    }
    if (effects) recommendations.push(`Effects: ${effects}`);
  }

  for (const ux of uxResults) {
    if (ux.Do) recommendations.push(`${ux.Category}: ${ux.Do}`);
    if (ux["Don't"]) components.push(`Avoid: ${ux["Don't"]}`);
  }

  if (landingResults[0]) {
    const landing = landingResults[0];
    if (landing['Section Order']) layout.Sections = landing['Section Order'];
    if (landing['Primary CTA Placement']) recommendations.push(`CTA Placement: ${landing['Primary CTA Placement']}`);
    if (landing['Color Strategy']) colors.Strategy = landing['Color Strategy'];
  }

  if (Object.keys(layout).length === 0) {
    layout['Max Width'] = '1200px';
    layout.Layout = 'Responsive grid';
  }

  if (recommendations.length === 0) {
    recommendations.push('Refer to MASTER.md for all design rules', 'Add specific overrides as needed for this page');
  }

  return {
    page_type: detectPageType(combinedContext),
    layout,
    spacing,
    typography,
    colors,
    components,
    unique_components: uniqueComponents,
    recommendations,
  };
}

function formatPageOverrideMd(designSystem, pageName, pageQuery = null) {
  const pageTitle = String(pageName).replaceAll('-', ' ').replaceAll('_', ' ').replace(/\b\w/g, (m) => m.toUpperCase());
  const overrides = generateIntelligentOverrides(pageName, pageQuery, designSystem);
  const section = (title, value, format) => {
    const lines = [`### ${title}`, ''];
    if (Array.isArray(value)) {
      if (value.length === 0) lines.push(`- No overrides — use Master ${format || title.toLowerCase()}`);
      else value.forEach((item) => lines.push(`- ${item}`));
    } else if (value && Object.keys(value).length > 0) {
      Object.entries(value).forEach(([key, item]) => lines.push(`- **${key}:** ${item}`));
    } else {
      lines.push(`- No overrides — use Master ${format || title.toLowerCase()}`);
    }
    lines.push('');
    return lines;
  };

  return [
    `# ${pageTitle} Page Overrides`,
    '',
    `> **PROJECT:** ${designSystem.project_name || 'PROJECT'}`,
    `> **Generated:** ${timestamp()}`,
    `> **Page Type:** ${overrides.page_type || 'General'}`,
    '',
    '> ⚠️ **IMPORTANT:** Rules in this file **override** the Master file (`design-system/MASTER.md`).',
    '> Only deviations from the Master are documented here. For all other rules, refer to the Master.',
    '',
    '---',
    '',
    '## Page-Specific Rules',
    '',
    ...section('Layout Overrides', overrides.layout, 'layout'),
    ...section('Spacing Overrides', overrides.spacing, 'spacing'),
    ...section('Typography Overrides', overrides.typography, 'typography'),
    ...section('Color Overrides', overrides.colors, 'colors'),
    ...section('Component Overrides', overrides.components, 'component specs'),
    '---',
    '',
    '## Page-Specific Components',
    '',
    ...(overrides.unique_components.length ? overrides.unique_components.map((item) => `- ${item}`) : ['- No unique components for this page']),
    '',
    '---',
    '',
    '## Recommendations',
    '',
    ...overrides.recommendations.map((item) => `- ${item}`),
    '',
  ].join('\n');
}

function persistDesignSystem(designSystem, pageName = null, outputDir = null, pageQuery = null) {
  const baseDir = outputDir || process.cwd();
  const projectSlug = slugify(designSystem.project_name || 'default');
  const designSystemDir = path.join(baseDir, 'design-system', projectSlug);
  const pagesDir = path.join(designSystemDir, 'pages');
  fs.mkdirSync(pagesDir, { recursive: true });

  const createdFiles = [];
  const masterFile = path.join(designSystemDir, 'MASTER.md');
  fs.writeFileSync(masterFile, formatMasterMd(designSystem), 'utf8');
  createdFiles.push(masterFile);

  if (pageName) {
    const pageFile = path.join(pagesDir, `${slugify(pageName)}.md`);
    fs.writeFileSync(pageFile, formatPageOverrideMd(designSystem, pageName, pageQuery), 'utf8');
    createdFiles.push(pageFile);
  }

  return {
    status: 'success',
    design_system_dir: designSystemDir,
    created_files: createdFiles,
  };
}

function generateDesignSystem(query, projectName = null, outputFormat = 'ascii', persist = false, pageName = null, outputDir = null) {
  const generator = new DesignSystemGenerator();
  const designSystem = generator.generate(query, projectName);
  if (persist) persistDesignSystem(designSystem, pageName, outputDir, query);
  return outputFormat === 'markdown' ? formatMarkdown(designSystem) : formatAsciiBox(designSystem);
}

module.exports = {
  DesignSystemGenerator,
  formatAsciiBox,
  formatMarkdown,
  formatMasterMd,
  formatPageOverrideMd,
  generateDesignSystem,
  persistDesignSystem,
};
