#!/usr/bin/env node

const { AVAILABLE_STACKS, CSV_CONFIG, MAX_RESULTS, search, searchStack } = require('./core.js');
const { generateDesignSystem } = require('./design_system.js');

function formatOutput(result) {
  if (result.error) {
    return `Error: ${result.error}`;
  }

  const output = [];
  if (result.stack) {
    output.push('## UI Pro Max Stack Guidelines');
    output.push(`**Stack:** ${result.stack} | **Query:** ${result.query}`);
  } else {
    output.push('## UI Pro Max Search Results');
    output.push(`**Domain:** ${result.domain} | **Query:** ${result.query}`);
  }
  output.push(`**Source:** ${result.file} | **Found:** ${result.count} results\n`);

  result.results.forEach((row, index) => {
    output.push(`### Result ${index + 1}`);
    Object.entries(row).forEach(([key, value]) => {
      let valueStr = String(value);
      if (valueStr.length > 300) {
        valueStr = `${valueStr.slice(0, 300)}...`;
      }
      output.push(`- **${key}:** ${valueStr}`);
    });
    output.push('');
  });

  return output.join('\n');
}

function parseArgs(argv) {
  const args = {
    query: null,
    domain: null,
    stack: null,
    maxResults: MAX_RESULTS,
    json: false,
    designSystem: false,
    projectName: null,
    format: 'ascii',
    persist: false,
    page: null,
    outputDir: null,
  };

  const remaining = [...argv];
  while (remaining.length > 0) {
    const token = remaining.shift();
    switch (token) {
      case '--domain':
      case '-d':
        args.domain = remaining.shift() ?? null;
        break;
      case '--stack':
      case '-s':
        args.stack = remaining.shift() ?? null;
        break;
      case '--max-results':
      case '-n':
        args.maxResults = Number.parseInt(remaining.shift() ?? String(MAX_RESULTS), 10);
        break;
      case '--json':
        args.json = true;
        break;
      case '--design-system':
      case '-ds':
        args.designSystem = true;
        break;
      case '--project-name':
      case '-p':
        args.projectName = remaining.shift() ?? null;
        break;
      case '--format':
      case '-f':
        args.format = remaining.shift() ?? 'ascii';
        break;
      case '--persist':
        args.persist = true;
        break;
      case '--page':
        args.page = remaining.shift() ?? null;
        break;
      case '--output-dir':
      case '-o':
        args.outputDir = remaining.shift() ?? null;
        break;
      default:
        if (!args.query) {
          args.query = token;
        }
        break;
    }
  }

  return args;
}

function usage() {
  return [
    'Usage: node search.js "<query>" [--domain <domain>] [--stack <stack>] [--max-results 3]',
    '       node search.js "<query>" --design-system [-p "Project Name"]',
    '       node search.js "<query>" --design-system --persist [-p "Project Name"] [--page "dashboard"]',
    '',
    `Domains: ${Object.keys(CSV_CONFIG).join(', ')}`,
    `Stacks: ${AVAILABLE_STACKS.join(', ')}`,
  ].join('\n');
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.query) {
    console.error(usage());
    process.exitCode = 1;
    return;
  }

  if (args.designSystem) {
    const output = generateDesignSystem(args.query, args.projectName, args.format, args.persist, args.page, args.outputDir);
    process.stdout.write(`${output}\n`);
    return;
  }

  let result;
  if (args.stack) {
    result = searchStack(args.query, args.stack, args.maxResults);
  } else {
    result = search(args.query, args.domain, args.maxResults);
  }

  if (args.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${formatOutput(result)}\n`);
}

if (require.main === module) {
  main();
}

module.exports = {
  formatOutput,
  main,
  parseArgs,
};
