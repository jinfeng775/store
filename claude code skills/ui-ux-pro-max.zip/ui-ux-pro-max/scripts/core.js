const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const MAX_RESULTS = 3;

const CSV_CONFIG = {
  style: {
    file: 'styles.csv',
    search_cols: ['Style Category', 'Keywords', 'Best For', 'Type', 'AI Prompt Keywords'],
    output_cols: ['Style Category', 'Type', 'Keywords', 'Primary Colors', 'Effects & Animation', 'Best For', 'Performance', 'Accessibility', 'Framework Compatibility', 'Complexity', 'AI Prompt Keywords', 'CSS/Technical Keywords', 'Implementation Checklist', 'Design System Variables'],
  },
  color: {
    file: 'colors.csv',
    search_cols: ['Product Type', 'Notes'],
    output_cols: ['Product Type', 'Primary (Hex)', 'Secondary (Hex)', 'CTA (Hex)', 'Background (Hex)', 'Text (Hex)', 'Notes'],
  },
  chart: {
    file: 'charts.csv',
    search_cols: ['Data Type', 'Keywords', 'Best Chart Type', 'Accessibility Notes'],
    output_cols: ['Data Type', 'Keywords', 'Best Chart Type', 'Secondary Options', 'Color Guidance', 'Accessibility Notes', 'Library Recommendation', 'Interactive Level'],
  },
  landing: {
    file: 'landing.csv',
    search_cols: ['Pattern Name', 'Keywords', 'Conversion Optimization', 'Section Order'],
    output_cols: ['Pattern Name', 'Keywords', 'Section Order', 'Primary CTA Placement', 'Color Strategy', 'Conversion Optimization'],
  },
  product: {
    file: 'products.csv',
    search_cols: ['Product Type', 'Keywords', 'Primary Style Recommendation', 'Key Considerations'],
    output_cols: ['Product Type', 'Keywords', 'Primary Style Recommendation', 'Secondary Styles', 'Landing Page Pattern', 'Dashboard Style (if applicable)', 'Color Palette Focus'],
  },
  ux: {
    file: 'ux-guidelines.csv',
    search_cols: ['Category', 'Issue', 'Description', 'Platform'],
    output_cols: ['Category', 'Issue', 'Platform', 'Description', 'Do', "Don't", 'Code Example Good', 'Code Example Bad', 'Severity'],
  },
  typography: {
    file: 'typography.csv',
    search_cols: ['Font Pairing Name', 'Category', 'Mood/Style Keywords', 'Best For', 'Heading Font', 'Body Font'],
    output_cols: ['Font Pairing Name', 'Category', 'Heading Font', 'Body Font', 'Mood/Style Keywords', 'Best For', 'Google Fonts URL', 'CSS Import', 'Tailwind Config', 'Notes'],
  },
  icons: {
    file: 'icons.csv',
    search_cols: ['Category', 'Icon Name', 'Keywords', 'Best For'],
    output_cols: ['Category', 'Icon Name', 'Keywords', 'Library', 'Import Code', 'Usage', 'Best For', 'Style'],
  },
  react: {
    file: 'react-performance.csv',
    search_cols: ['Category', 'Issue', 'Keywords', 'Description'],
    output_cols: ['Category', 'Issue', 'Platform', 'Description', 'Do', "Don't", 'Code Example Good', 'Code Example Bad', 'Severity'],
  },
  web: {
    file: 'web-interface.csv',
    search_cols: ['Category', 'Issue', 'Keywords', 'Description'],
    output_cols: ['Category', 'Issue', 'Platform', 'Description', 'Do', "Don't", 'Code Example Good', 'Code Example Bad', 'Severity'],
  },
};

const STACK_CONFIG = {
  'html-tailwind': { file: 'stacks/html-tailwind.csv' },
  react: { file: 'stacks/react.csv' },
  nextjs: { file: 'stacks/nextjs.csv' },
  astro: { file: 'stacks/astro.csv' },
  vue: { file: 'stacks/vue.csv' },
  nuxtjs: { file: 'stacks/nuxtjs.csv' },
  'nuxt-ui': { file: 'stacks/nuxt-ui.csv' },
  svelte: { file: 'stacks/svelte.csv' },
  swiftui: { file: 'stacks/swiftui.csv' },
  'react-native': { file: 'stacks/react-native.csv' },
  flutter: { file: 'stacks/flutter.csv' },
  shadcn: { file: 'stacks/shadcn.csv' },
  'jetpack-compose': { file: 'stacks/jetpack-compose.csv' },
};

const STACK_COLS = {
  search_cols: ['Category', 'Guideline', 'Description', 'Do', "Don't"],
  output_cols: ['Category', 'Guideline', 'Description', 'Do', "Don't", 'Code Good', 'Code Bad', 'Severity', 'Docs URL'],
};

const AVAILABLE_STACKS = Object.keys(STACK_CONFIG);

function parseCsv(content) {
  const rows = [];
  let field = '';
  let row = [];
  let inQuotes = false;

  for (let i = 0; i < content.length; i += 1) {
    const char = content[i];
    const next = content[i + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        field += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      row.push(field);
      field = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && next === '\n') {
        i += 1;
      }
      row.push(field);
      field = '';
      if (row.length > 1 || row[0] !== '') {
        rows.push(row);
      }
      row = [];
    } else {
      field += char;
    }
  }

  if (field !== '' || row.length > 0) {
    row.push(field);
    rows.push(row);
  }

  if (rows.length === 0) {
    return [];
  }

  const headers = rows[0].map((header) => header.replace(/^\uFEFF/, ''));
  return rows.slice(1).map((values) => {
    const entry = {};
    headers.forEach((header, index) => {
      entry[header] = values[index] ?? '';
    });
    return entry;
  });
}

function loadCsv(filepath) {
  const content = fs.readFileSync(filepath, 'utf8');
  return parseCsv(content);
}

class BM25 {
  constructor(k1 = 1.5, b = 0.75) {
    this.k1 = k1;
    this.b = b;
    this.corpus = [];
    this.docLengths = [];
    this.avgdl = 0;
    this.idf = new Map();
    this.docFreqs = new Map();
    this.N = 0;
  }

  tokenize(text) {
    return String(text)
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter((word) => word.length > 2);
  }

  fit(documents) {
    this.corpus = documents.map((doc) => this.tokenize(doc));
    this.N = this.corpus.length;
    if (this.N === 0) return;

    this.docLengths = this.corpus.map((doc) => doc.length);
    this.avgdl = this.docLengths.reduce((sum, len) => sum + len, 0) / this.N;

    for (const doc of this.corpus) {
      const seen = new Set();
      for (const word of doc) {
        if (!seen.has(word)) {
          this.docFreqs.set(word, (this.docFreqs.get(word) ?? 0) + 1);
          seen.add(word);
        }
      }
    }

    for (const [word, freq] of this.docFreqs.entries()) {
      this.idf.set(word, Math.log((this.N - freq + 0.5) / (freq + 0.5) + 1));
    }
  }

  score(query) {
    const queryTokens = this.tokenize(query);
    return this.corpus
      .map((doc, idx) => {
        const docLen = this.docLengths[idx];
        const termFreqs = new Map();
        for (const word of doc) {
          termFreqs.set(word, (termFreqs.get(word) ?? 0) + 1);
        }

        let score = 0;
        for (const token of queryTokens) {
          if (!this.idf.has(token)) continue;
          const tf = termFreqs.get(token) ?? 0;
          const idf = this.idf.get(token);
          const numerator = tf * (this.k1 + 1);
          const denominator = tf + this.k1 * (1 - this.b + (this.b * docLen) / this.avgdl);
          score += idf * numerator / denominator;
        }

        return [idx, score];
      })
      .sort((a, b) => b[1] - a[1]);
  }
}

function searchCsv(filepath, searchCols, outputCols, query, maxResults) {
  if (!fs.existsSync(filepath)) {
    return [];
  }

  const data = loadCsv(filepath);
  const documents = data.map((row) => searchCols.map((col) => String(row[col] ?? '')).join(' '));
  const bm25 = new BM25();
  bm25.fit(documents);
  const ranked = bm25.score(query);

  const results = [];
  for (const [idx, score] of ranked.slice(0, maxResults)) {
    if (score <= 0) continue;
    const row = data[idx];
    const filtered = {};
    for (const col of outputCols) {
      if (Object.prototype.hasOwnProperty.call(row, col)) {
        filtered[col] = row[col] ?? '';
      }
    }
    results.push(filtered);
  }

  return results;
}

function detectDomain(query) {
  const queryLower = query.toLowerCase();
  const domainKeywords = {
    color: ['color', 'palette', 'hex', '#', 'rgb'],
    chart: ['chart', 'graph', 'visualization', 'trend', 'bar', 'pie', 'scatter', 'heatmap', 'funnel'],
    landing: ['landing', 'page', 'cta', 'conversion', 'hero', 'testimonial', 'pricing', 'section'],
    product: ['saas', 'ecommerce', 'e-commerce', 'fintech', 'healthcare', 'gaming', 'portfolio', 'crypto', 'dashboard'],
    style: ['style', 'design', 'ui', 'minimalism', 'glassmorphism', 'neumorphism', 'brutalism', 'dark mode', 'flat', 'aurora', 'prompt', 'css', 'implementation', 'variable', 'checklist', 'tailwind'],
    ux: ['ux', 'usability', 'accessibility', 'wcag', 'touch', 'scroll', 'animation', 'keyboard', 'navigation', 'mobile'],
    typography: ['font', 'typography', 'heading', 'serif', 'sans'],
    icons: ['icon', 'icons', 'lucide', 'heroicons', 'symbol', 'glyph', 'pictogram', 'svg icon'],
    react: ['react', 'next.js', 'nextjs', 'suspense', 'memo', 'usecallback', 'useeffect', 'rerender', 'bundle', 'waterfall', 'barrel', 'dynamic import', 'rsc', 'server component'],
    web: ['aria', 'focus', 'outline', 'semantic', 'virtualize', 'autocomplete', 'form', 'input type', 'preconnect'],
  };

  let best = 'style';
  let bestScore = 0;

  for (const [domain, keywords] of Object.entries(domainKeywords)) {
    const score = keywords.reduce((sum, keyword) => sum + (queryLower.includes(keyword) ? 1 : 0), 0);
    if (score > bestScore) {
      best = domain;
      bestScore = score;
    }
  }

  return bestScore > 0 ? best : 'style';
}

function search(query, domain = null, maxResults = MAX_RESULTS) {
  const resolvedDomain = domain ?? detectDomain(query);
  const config = CSV_CONFIG[resolvedDomain] ?? CSV_CONFIG.style;
  const filepath = path.join(DATA_DIR, config.file);

  if (!fs.existsSync(filepath)) {
    return { error: `File not found: ${filepath}`, domain: resolvedDomain };
  }

  const results = searchCsv(filepath, config.search_cols, config.output_cols, query, maxResults);

  return {
    domain: resolvedDomain,
    query,
    file: config.file,
    count: results.length,
    results,
  };
}

function searchStack(query, stack, maxResults = MAX_RESULTS) {
  if (!STACK_CONFIG[stack]) {
    return { error: `Unknown stack: ${stack}. Available: ${AVAILABLE_STACKS.join(', ')}` };
  }

  const filepath = path.join(DATA_DIR, STACK_CONFIG[stack].file);
  if (!fs.existsSync(filepath)) {
    return { error: `Stack file not found: ${filepath}`, stack };
  }

  const results = searchCsv(filepath, STACK_COLS.search_cols, STACK_COLS.output_cols, query, maxResults);
  return {
    domain: 'stack',
    stack,
    query,
    file: STACK_CONFIG[stack].file,
    count: results.length,
    results,
  };
}

module.exports = {
  AVAILABLE_STACKS,
  CSV_CONFIG,
  DATA_DIR,
  MAX_RESULTS,
  STACK_CONFIG,
  BM25,
  detectDomain,
  loadCsv,
  parseCsv,
  search,
  searchStack,
};
