# Planning with Files for 通义灵码

一个面向**通义灵码**工作流的 `planning-with-files` 技能/提示包，用持久化 Markdown 文件管理复杂任务的计划、发现和进度。

## 这是什么

这个仓库把 `planning-with-files` 从多平台分发工程收敛为一个单平台版本：

- 保留 `planning-with-files` 作为核心能力名
- 保留三文件工作流与模板、脚本等核心资产
- 删除其他 IDE / Agent 平台的适配层、插件清单和平台专属文档
- 将入口说明改写为更适合通义灵码场景的技能/提示包用法

## 核心能力

`planning-with-files` 的目标很简单：

- 把复杂任务拆成清晰阶段
- 把研究结果写入文件，而不是堆在上下文里
- 把进度、错误和验证结果持续记录下来
- 在长会话或多轮协作中降低目标漂移

### 三文件模式

每个复杂任务使用三个文件：

```text
task_plan.md   -> 任务阶段、状态、决策、错误
findings.md    -> 调研发现、技术结论、参考资料
progress.md    -> 执行记录、修改摘要、测试结果
```

核心原则：

```text
Context Window = RAM
Filesystem = Disk

重要信息写入磁盘，不只留在上下文里。
```

## 适用场景

适合：

- 多步骤开发任务
- 需求分析与技术调研
- 重构、排障、迁移
- 会话很长、信息容易丢失的任务

不适合：

- 一次性简单问答
- 单个小改动
- 不需要持续跟踪的临时操作

## 在通义灵码中的使用方式

由于不同安装环境的通义灵码接入方式可能不同，这个仓库保持为**技能/提示包结构**，方便你按自己的环境接入。

推荐做法：

1. 将仓库放到你的通义灵码工作区或自定义提示资产目录中
2. 使用 [skills/planning-with-files/SKILL.md](skills/planning-with-files/SKILL.md) 作为主技能说明
3. 使用根目录 [templates/](templates/) 作为任务模板来源
4. 使用根目录 [scripts/](scripts/) 辅助初始化和完成校验

如果你的通义灵码环境不支持“技能目录”自动发现，也可以直接把 `SKILL.md` 内容作为长期系统提示或团队规范使用。

详细说明见 [docs/installation.md](docs/installation.md)。

## 使用流程

### 1. 创建三个任务文件

从 [templates/](templates/) 复制：

- `task_plan.md`
- `findings.md`
- `progress.md`

### 2. 先做计划，再开始执行

在 `task_plan.md` 中写清：

- 目标
- 阶段拆分
- 当前状态
- 已知风险

### 3. 过程中的发现要落盘

- 调研结论写进 `findings.md`
- 执行动作和验证结果写进 `progress.md`
- 遇到错误也要记录，避免重复踩坑

### 4. 完成前做一次收尾检查

使用：

- [scripts/init-session.sh](scripts/init-session.sh)
- [scripts/check-complete.sh](scripts/check-complete.sh)
- PowerShell 对应脚本

更多细节见：

- [docs/quickstart.md](docs/quickstart.md)
- [docs/workflow.md](docs/workflow.md)
- [docs/troubleshooting.md](docs/troubleshooting.md)

## 仓库结构

```text
planning-with-files/
├── skills/
│   └── planning-with-files/
│       ├── SKILL.md
│       ├── examples.md
│       ├── reference.md
│       ├── templates/
│       └── scripts/
├── templates/
├── scripts/
├── docs/
│   ├── installation.md
│   ├── quickstart.md
│   ├── workflow.md
│   ├── troubleshooting.md
│   └── windows.md
├── examples/
├── CHANGELOG.md
├── LICENSE
└── README.md
```

## 保留内容说明

这个版本保留的是与 `planning-with-files` 方法本身强相关的部分：

- 核心技能说明
- 三文件模板
- 初始化与完成校验脚本
- 通用文档
- 通用示例与参考资料

已经移除的内容包括：

- 已移除旧版插件元数据与命令式分发文件
- 已移除其他非目标平台适配层
- 多平台同步脚本
- 平台专属安装与接入文档
- 仅服务其他平台的命令入口

## 文档索引

- [安装说明](docs/installation.md)
- [快速开始](docs/quickstart.md)
- [工作流说明](docs/workflow.md)
- [故障排查](docs/troubleshooting.md)
- [Windows 使用说明](docs/windows.md)

## 许可

MIT License.
