# Reference: File-Based Context Management Principles

这份参考文档总结了 `planning-with-files` 所采用的通用上下文管理原则。它不依赖某个特定平台品牌，而是关注：如何在复杂任务中用文件管理目标、发现和进度。

## 6 个核心原则

### Principle 1: Keep Context Stable

长任务中，稳定的上下文结构比堆积更多内容更重要。

**建议：**
- 保持计划结构稳定
- 避免频繁改写任务目标表述
- 把新增信息追加到文件中，而不是反复重写全部上下文

### Principle 2: Prefer Consistent Action Shapes

一致的动作模式更容易维护，也更容易回溯。

**建议：**
- 搜索、阅读、记录、验证这些动作尽量形成固定节奏
- 重要决策前先回看计划
- 重要发现及时落盘

### Principle 3: Use Filesystem as External Memory

```text
Context Window = RAM
Filesystem = Disk
```

在长任务里，文件系统就是外部记忆区。

**建议：**
- 目标写到 `task_plan.md`
- 发现写到 `findings.md`
- 执行与验证写到 `progress.md`

### Principle 4: Refresh Goals Before Decisions

复杂任务中，执行轮次一多，原始目标很容易被后续细节淹没。

**建议：**
- 在重要决策前重新查看 `task_plan.md`
- 确保“当前阶段、下一步、最终目标”仍然清晰

### Principle 5: Keep Error History

错误记录不是噪音，而是后续决策的输入。

**建议：**
- 记录错误现象
- 记录尝试次数
- 记录最终解决方式
- 避免重复相同失败动作

### Principle 6: Avoid Blind Repetition

重复相似动作时，最容易产生机械化偏差和目标漂移。

**建议：**
- 出现重复失败后及时换方法
- 阶段切换时重新整理计划
- 定期把零散结论整理进文件

---

## 3 种上下文管理策略

### Strategy 1: Context Reduction

并不是所有信息都要一直停留在实时上下文里。

**做法：**
- 保留最近关键内容在上下文中
- 把详细过程和原始结果存进文件
- 需要时再回读

### Strategy 2: Context Isolation

把不同类型的信息分开放置，可以减少干扰。

**做法：**
- `task_plan.md` 管目标和阶段
- `findings.md` 管发现和判断
- `progress.md` 管动作和验证

### Strategy 3: Context Offloading

把大块细节从即时上下文卸载到文件，可以让后续推理更聚焦。

**做法：**
- 不把所有历史细节都留在对话里
- 通过文件记录完整过程
- 只在需要时重新提取关键部分

---

## 推荐执行循环

复杂任务可以按下面循环推进：

```text
1. 理解目标
2. 读取当前计划
3. 选择下一步动作
4. 执行动作
5. 记录结果
6. 更新计划/发现/进度
7. 继续下一轮
```

---

## 三个关键文件的职责

| File | Purpose | When to Update |
|------|---------|----------------|
| `task_plan.md` | 目标、阶段、决策、错误 | 阶段变化后 |
| `findings.md` | 调研结论、技术判断、参考资料 | 有新发现后 |
| `progress.md` | 执行动作、验证结果、修改记录 | 实施和验证过程中 |

---

## 关键约束

- **先有计划，再做复杂执行**
- **错误必须记录**
- **失败后不能机械重试同一路径**
- **阶段状态必须持续更新**
- **文件是长期记忆，不是装饰**

---

## 核心提醒

> 复杂任务的问题，往往不是“做不到”，而是“做着做着忘了原本要做什么”。

`planning-with-files` 的作用，就是把目标、发现和进度持续固定在文件里，让任务始终可恢复、可追踪、可验证。
