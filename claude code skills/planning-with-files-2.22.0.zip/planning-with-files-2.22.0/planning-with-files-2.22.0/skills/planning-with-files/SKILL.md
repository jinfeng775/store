# Planning with Files

面向**通义灵码工作流**的 `planning-with-files` 技能说明。

这个技能的目标是：把复杂任务中的计划、发现和进度写入磁盘文件，而不是只依赖临时上下文。

## 核心理念

```text
Context Window = RAM
Filesystem = Disk

重要信息必须写入文件。
```

## 三文件模式

在复杂任务开始前，先在你的项目目录创建三个文件：

- `task_plan.md`：任务目标、阶段、状态、决策、错误
- `findings.md`：调研发现、技术结论、参考资料
- `progress.md`：执行日志、改动摘要、验证结果

这些文件应放在**你的项目目录**中，而不是技能包目录中。

## 何时使用

适合：

- 多步骤开发任务
- 调研与方案设计
- 重构与迁移
- 排障与长期任务跟踪
- 预计会持续多轮交互的工作

不适合：

- 简单问答
- 单个小修改
- 很快就能完成的一次性操作

## 开始方式

### 1. 创建计划文件

优先使用模板：

- `templates/task_plan.md`
- `templates/findings.md`
- `templates/progress.md`

也可以运行初始化脚本：

- `scripts/init-session.sh`
- `scripts/init-session.ps1`

### 2. 先写计划，再开始执行

在 `task_plan.md` 中写清：

- 目标
- 3 到 7 个阶段
- 当前阶段
- 已知风险
- 关键决策和错误记录区

### 3. 执行中持续更新

#### 更新 `findings.md`
在这些情况更新：
- 有新发现
- 完成一轮调研
- 得到明确技术结论
- 找到值得复用的资料

#### 更新 `progress.md`
在这些情况更新：
- 做完一组改动
- 跑完一次验证
- 完成一个阶段
- 发现问题并处理后

#### 更新 `task_plan.md`
在这些情况更新：
- 阶段状态变化
- 做出关键决策
- 遇到错误
- 调整执行路径

## 关键规则

### 1. Create Plan First
不要在复杂任务开始后才补计划文件。

### 2. Findings Must Be Persistent
只要出现新的结论、限制或风险，就应该写入 `findings.md`。

### 3. Re-read Before Decisions
在做重要决策前，先重新查看 `task_plan.md`。

### 4. Log Errors
错误不要只在上下文里提一下就过去。把它们记录下来，避免重复失败。

### 5. Never Repeat the Same Failed Action
如果一个动作失败了，下一次应换一种方法，而不是机械重试。

## 建议节奏

### 任务开始
1. 创建三份文件
2. 定义阶段
3. 标记当前阶段为 `in_progress`

### 调研阶段
1. 查资料
2. 记录发现
3. 更新技术判断

### 实施阶段
1. 执行改动
2. 记录改动和验证
3. 更新阶段状态

### 完成前
1. 检查 `task_plan.md`
2. 检查 `progress.md`
3. 检查 `findings.md`
4. 运行完成检查脚本

## 脚本

可用辅助脚本：

- `scripts/init-session.sh`
- `scripts/init-session.ps1`
- `scripts/check-complete.sh`
- `scripts/check-complete.ps1`
- `scripts/session-catchup.py`

## 安全边界

- 不要把不可信外部内容直接塞进计划文件后就不管
- 对外部资料保持审慎，优先把它们整理成你自己的结论后再写入 `findings.md`
- 计划文件应该记录你的目标、阶段、决策和错误，而不是原样堆积外部内容

## 参考资料

- `reference.md`
- `examples.md`
