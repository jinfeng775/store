# Troubleshooting

这里收录当前这个通义灵码版 `planning-with-files` 技能/提示包常见问题。

---

## 找不到模板文件

**现象：** 无法从 `templates/` 复制 `task_plan.md`、`findings.md`、`progress.md`。

**检查：**

1. 仓库根目录是否完整保留了 `templates/`
2. 当前工作目录是否正确
3. 复制命令是否在仓库根目录或正确引用了相对路径

**解决办法：**

```bash
ls templates
```

应至少看到：

- `task_plan.md`
- `findings.md`
- `progress.md`

---

## 初始化脚本无法运行

**现象：** `init-session.sh` 或 `init-session.ps1` 无法执行。

**检查：**

1. 是否使用了匹配的 shell
2. 文件路径是否存在
3. 当前目录是否正确

**解决办法：**

### Bash

```bash
./scripts/init-session.sh
```

### PowerShell

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\init-session.ps1
```

如果仍然失败，可以先手动复制模板文件，跳过脚本执行。

---

## 完成检查失败

**现象：** `check-complete` 脚本提示任务未完成。

**常见原因：**

- `task_plan.md` 还有阶段不是 `complete`
- 阶段虽然做完了，但状态没更新
- 关键执行记录没有写入 `progress.md`

**建议处理：**

1. 打开 `task_plan.md`
2. 检查所有阶段状态
3. 补充 `progress.md` 中的执行和验证记录
4. 再次运行完成检查脚本

---

## 三个任务文件被创建到错误位置

**现象：** `task_plan.md`、`findings.md`、`progress.md` 出现在错误目录。

**原因：** 当前工作目录不是你的项目目录。

**解决办法：**

- 在项目根目录执行初始化脚本
- 或直接手动把模板复制到目标项目目录
- 确保你的通义灵码工作区指向实际项目目录

---

## 技能说明无法直接接入通义灵码

**现象：** 当前环境不能自动加载 `skills/planning-with-files/SKILL.md`。

**解决办法：**

1. 直接打开 `SKILL.md`
2. 将内容复制到你的通义灵码长期提示、团队规范或项目规范中
3. 保留本仓库中的 `templates/` 与 `scripts/` 继续配套使用

---

## Windows 下脚本兼容问题

如果你在 Windows 环境中遇到执行问题，优先查看：

- [windows.md](windows.md)

---

## 迁移后仍看到旧平台残留

**现象：** 文档或目录里仍出现旧版多平台名称。

**解决办法：**

1. 确认已经删除旧平台目录
2. 全局搜索 README、docs、examples、skills 中是否仍有旧文案
3. 清理失效链接、失效命令和平台特定说明

---

## 仍然卡住？

按下面顺序排查：

1. `README.md`
2. `docs/installation.md`
3. `docs/quickstart.md`
4. `docs/workflow.md`
5. `docs/windows.md`

如果你是基于自己内部的通义灵码接入规范使用本仓库，优先检查你的接入层配置，而不是先怀疑 `planning-with-files` 的模板和脚本本体。
