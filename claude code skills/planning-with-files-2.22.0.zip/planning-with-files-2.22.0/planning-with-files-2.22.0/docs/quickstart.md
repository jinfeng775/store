# Quick Start Guide

下面用 5 个步骤开始使用 `planning-with-files`。

---

## Step 1: 准备技能说明与模板

确认以下内容可用：

- `skills/planning-with-files/SKILL.md`
- `templates/task_plan.md`
- `templates/findings.md`
- `templates/progress.md`

如果你的通义灵码环境支持自定义技能或长期提示，把 `SKILL.md` 接入你的环境；如果不支持，也可以把它作为项目工作规范直接使用。

---

## Step 2: 为当前任务创建三个文件

在你的项目目录创建：

- `task_plan.md`
- `findings.md`
- `progress.md`

可以直接复制模板：

```bash
cp templates/task_plan.md ./task_plan.md
cp templates/findings.md ./findings.md
cp templates/progress.md ./progress.md
```

或运行：

```bash
./scripts/init-session.sh
```

---

## Step 3: 先计划，再执行

在 `task_plan.md` 中写清：

- 目标
- 3 到 7 个阶段
- 当前阶段
- 风险、决策、错误记录区

示例：

```markdown
### Phase 1: Discovery
- [ ] Understand request
- [ ] Inspect existing files
- **Status:** in_progress

### Phase 2: Implementation
- [ ] Update core files
- [ ] Verify behavior
- **Status:** pending
```

---

## Step 4: 执行过程中持续写入

### `findings.md`
写：
- 调研结果
- 技术判断
- 参考资料
- 关键发现

### `progress.md`
写：
- 做了什么
- 改了哪些文件
- 跑了哪些验证
- 遇到了什么问题

### `task_plan.md`
写：
- 阶段状态变化
- 关键决策
- 错误与处理结果

推荐习惯：

- 有新发现就更新 `findings.md`
- 完成一个阶段就更新 `task_plan.md` 和 `progress.md`
- 发现错误就立刻记录，避免重复尝试

---

## Step 5: 完成前执行检查

确认：

1. `task_plan.md` 中所有阶段状态都已更新
2. `progress.md` 中已经记录主要动作与验证结果
3. `findings.md` 中保留了关键结论

然后运行完成检查脚本：

```bash
./scripts/check-complete.sh
```

或 PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check-complete.ps1
```

---

## Quick Reference

| 文件 | 什么时候更新 | 内容 |
|------|---------------|------|
| `task_plan.md` | 开始任务、阶段变化、遇到错误时 | 阶段、状态、决策、错误 |
| `findings.md` | 有新发现、调研后 | 发现、结论、参考资料 |
| `progress.md` | 执行中、验证后 | 动作日志、测试结果、修改记录 |

---

## 下一步

- 查看 [workflow.md](workflow.md)
- 查看 [troubleshooting.md](troubleshooting.md)
- 查看 [../examples/README.md](../examples/README.md)
