# Installation Guide

本仓库当前以**通义灵码技能/提示包**的形式维护，不再包含面向其他 IDE / Agent 平台的专属安装结构。

## 安装目标

你需要把以下内容提供给通义灵码环境：

- 主技能说明：`skills/planning-with-files/SKILL.md`
- 模板目录：`templates/`
- 脚本目录：`scripts/`

## 推荐安装方式

### 方式 1：作为本地技能/提示包使用

适合你已经有一套通义灵码自定义提示、团队规范或工作区资产管理方式。

建议保留以下目录结构：

```text
planning-with-files/
├── skills/planning-with-files/SKILL.md
├── templates/
└── scripts/
```

接入时：

1. 将仓库复制到你的通义灵码工作区或统一资产目录
2. 让通义灵码读取 `skills/planning-with-files/SKILL.md`
3. 保证 `templates/` 与 `scripts/` 可被同目录引用

### 方式 2：作为长期提示词/团队规范使用

如果你的环境不支持自动加载技能目录：

1. 打开 `skills/planning-with-files/SKILL.md`
2. 将其中内容作为通义灵码的长期系统提示、团队规范或项目级提示
3. 继续保留本仓库中的 `templates/` 与 `scripts/` 作为配套资源

## 初始化任务文件

开始复杂任务前，先把模板复制到你的项目目录：

### Bash

```bash
cp templates/task_plan.md ./task_plan.md
cp templates/findings.md ./findings.md
cp templates/progress.md ./progress.md
```

### PowerShell

```powershell
Copy-Item templates\task_plan.md .
Copy-Item templates\findings.md .
Copy-Item templates\progress.md .
```

或者直接运行初始化脚本：

### Bash

```bash
./scripts/init-session.sh
```

### PowerShell

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\init-session.ps1
```

## 安装后验证

安装完成后，至少确认以下几点：

1. 你能访问 `skills/planning-with-files/SKILL.md`
2. 你能从 `templates/` 复制出三个任务文件
3. `scripts/` 中的初始化脚本可运行
4. `scripts/check-complete.sh` 或 `check-complete.ps1` 能在任务目录中检查完成状态

## 更新方式

如果你是通过 git 拉取此仓库使用：

```bash
git pull
```

更新后建议重新检查：

- `SKILL.md` 是否仍符合你的通义灵码接入方式
- `templates/` 是否需要同步到你的项目模板目录
- `scripts/` 是否与当前操作系统兼容

## 卸载方式

如果你不再使用这个技能包，删除仓库目录以及你在通义灵码环境中引用它的配置即可。

## 注意事项

- 本仓库**不再提供**旧版插件安装命令
- 本仓库**不再包含**其他平台专属 hooks、命令和 marketplace 元数据
- 因为当前没有统一的通义灵码官方目录规范，仓库保留了最容易迁移和复用的技能包结构

## 需要帮助？

先查看：

- [快速开始](quickstart.md)
- [工作流说明](workflow.md)
- [故障排查](troubleshooting.md)
- [Windows 使用说明](windows.md)
