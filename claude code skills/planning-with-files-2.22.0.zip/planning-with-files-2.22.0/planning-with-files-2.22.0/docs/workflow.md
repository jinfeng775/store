# Workflow Diagram

这个工作流说明 `planning-with-files` 如何通过三份 Markdown 文件管理复杂任务。

---

## Overall Flow

```text
任务开始
  ↓
创建 task_plan.md
  ↓
创建 findings.md / progress.md
  ↓
开始执行
  ├─ 调研 -> findings.md
  ├─ 修改/实现 -> progress.md
  ├─ 阶段变化 -> task_plan.md
  └─ 发生错误 -> task_plan.md + progress.md
  ↓
完成检查
  ↓
交付结果
```

---

## 三个文件如何分工

### 1. `task_plan.md`
用于记录：

- 目标
- 阶段拆解
- 当前状态
- 决策
- 错误与处理方式

它回答的是：

- 现在做到哪一步了？
- 后面还剩什么？
- 为什么这么做？

### 2. `findings.md`
用于记录：

- 调研过程中的发现
- 关键技术结论
- 有价值的资料和链接
- 需要反复参考的信息

它回答的是：

- 我已经确认了什么？
- 哪些信息值得保留？

### 3. `progress.md`
用于记录：

- 执行动作
- 改动过的文件
- 运行过的验证
- 错误日志

它回答的是：

- 我已经做了什么？
- 我如何验证过？

---

## 推荐执行节奏

### 任务开始时

1. 创建三份文件
2. 在 `task_plan.md` 写目标和阶段
3. 把当前阶段标记为 `in_progress`

### 调研阶段

- 每次拿到明确结论，更新 `findings.md`
- 做出技术取舍时，把原因记下来

### 实施阶段

- 每完成一组改动，更新 `progress.md`
- 如果阶段发生变化，更新 `task_plan.md`

### 出现问题时

- 在 `task_plan.md` 记录错误及解决方案
- 在 `progress.md` 记录时间点和实际影响
- 不要重复同样的失败操作

### 任务完成前

- 回看 `task_plan.md` 是否所有阶段状态已更新
- 回看 `progress.md` 是否记录了验证结果
- 回看 `findings.md` 是否保留了关键结论

---

## 5-Question Reboot Check

如果中途暂停、换人、换上下文，优先检查这 5 个问题：

| 问题 | 看哪个文件 |
|------|------------|
| 我现在在哪？ | `task_plan.md` |
| 下一步做什么？ | `task_plan.md` |
| 目标是什么？ | `task_plan.md` |
| 已经学到了什么？ | `findings.md` |
| 已经做了什么？ | `progress.md` |

---

## Completion Check

建议在结束前运行：

```bash
./scripts/check-complete.sh
```

如果你使用 PowerShell：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check-complete.ps1
```

---

## Related Docs

- [quickstart.md](quickstart.md)
- [troubleshooting.md](troubleshooting.md)
- [../examples/README.md](../examples/README.md)
