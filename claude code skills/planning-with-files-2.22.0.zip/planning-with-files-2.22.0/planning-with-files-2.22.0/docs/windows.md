# Windows Guide

本页说明在 Windows 环境下使用当前通义灵码版 `planning-with-files` 技能/提示包的建议方式。

---

## 推荐环境

Windows 下推荐以下任一方式运行脚本：

1. PowerShell
2. Git Bash
3. WSL

如果你不想运行脚本，也可以直接手动复制模板文件。

---

## 复制模板文件

### PowerShell

```powershell
Copy-Item templates\task_plan.md .
Copy-Item templates\findings.md .
Copy-Item templates\progress.md .
```

### Git Bash

```bash
cp templates/task_plan.md ./task_plan.md
cp templates/findings.md ./findings.md
cp templates/progress.md ./progress.md
```

---

## 运行初始化脚本

### PowerShell

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\init-session.ps1
```

### Git Bash

```bash
./scripts/init-session.sh
```

---

## 运行完成检查

### PowerShell

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check-complete.ps1
```

### Git Bash

```bash
./scripts/check-complete.sh
```

---

## 常见问题

### 1. 执行策略拦截 PowerShell 脚本

可以临时使用：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\init-session.ps1
```

### 2. 相对路径不正确

请确认你当前所在目录就是仓库根目录，或者命令里使用了正确的相对路径。

### 3. 行尾或编码问题

如果文件显示异常，优先确认你的编辑器使用 UTF-8 编码，并避免在不同工具之间反复转换行尾格式。

---

## 建议

如果你的通义灵码环境本身运行在 Windows IDE 中，但更适合调用 Unix 风格脚本，优先使用 Git Bash 或 WSL；如果更偏向本地自动化，则优先使用 PowerShell 脚本。
