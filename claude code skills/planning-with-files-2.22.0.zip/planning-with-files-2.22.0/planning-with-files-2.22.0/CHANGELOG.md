# Changelog

All notable changes to this repository are documented in this file.

## [tongyi-lingma-refocus] - 2026-03-22

### Changed

- Refocused the repository into a 通义灵码-oriented `planning-with-files` skill/prompt package
- Removed legacy distribution layers and documents not needed by the current package
- Rewrote the main documentation to describe a single-platform skill package workflow
- Kept `planning-with-files` as the core capability name while preserving the file-based planning model, templates, and scripts

### Removed

- Legacy plugin metadata and command-oriented distribution files
- Non-target platform adapters and their duplicated documentation
- Multi-distribution sync tooling that only served the old replicated package layout
