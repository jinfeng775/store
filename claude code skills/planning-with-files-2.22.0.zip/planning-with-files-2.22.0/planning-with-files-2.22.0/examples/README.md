# Examples: Planning with Files in Action

这个目录展示 `planning-with-files` 三文件模式如何在真实任务中使用。

## Example: Building a Todo App

这个示例展示一个完整任务从开始到结束的过程，以及 `task_plan.md`、`findings.md`、`progress.md` 如何配合演进。

### 示例重点

- 如何先建计划，再开始执行
- 如何把调研发现写入 `findings.md`
- 如何把执行与验证写入 `progress.md`
- 如何用 `task_plan.md` 管理阶段状态

## 建议阅读方式

1. 先看任务初始状态
2. 再看调研后如何更新计划
3. 最后看实现和验证阶段如何记录

如果你在通义灵码环境中使用这个技能包，可以把这些示例当作：

- 团队规范参考
- 提示词示例
- 任务文件填写样例

其余内容继续沿用下方完整示例。
